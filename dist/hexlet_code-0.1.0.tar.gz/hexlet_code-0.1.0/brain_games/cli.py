# brain_games/cli.py

def main():
    print("Welcome to the Brain Games!")
    name = input("May I have your name? ")
    print(f"Hello, {name}!")

if __name__ == '__main__':
    main()
