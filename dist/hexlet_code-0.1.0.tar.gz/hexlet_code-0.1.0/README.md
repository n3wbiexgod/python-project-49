# Asciinema brain-progression demo
[![asciicast](https://asciinema.org/a/665488.svg)](https://asciinema.org/a/665488)
# Asciinema brain-gcd demo
[![asciicast](https://asciinema.org/a/665212.svg)](https://asciinema.org/a/665212)
# Asciinema brain-calc demo
[![asciicast](https://asciinema.org/a/665062.svg)](https://asciinema.org/a/665062)
# Asciinema brain-even demo
[![asciicast](https://asciinema.org/a/664964.svg)](https://asciinema.org/a/664964)
# Maintainability badge:
[![Maintainability](https://api.codeclimate.com/v1/badges/39adac5432c17461fe9a/maintainability)](https://codeclimate.com/github/n3wbiexgod/python-project-49/maintainability)
### Hexlet tests and linter status:
[![Actions Status](https://github.com/n3wbiexgod/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/n3wbiexgod/python-project-49/actions)
